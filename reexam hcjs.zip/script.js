/* ============================================================
   script.js  –  StayHopper Boutique Hotel
   B.Tech CSE Semester II Case Study Project

   This file contains all the JavaScript for the website.
   JavaScript makes the page interactive (buttons work, prices
   calculate, images slide, etc.)

   TABLE OF CONTENTS:
   1. Navigation – hamburger menu toggle
   2. Image Slider – auto-play + manual controls
   3. Booking Page – set minimum date for date pickers
   4. Price Calculator – main logic with all rules
   5. Booking Confirmation – validate form and show success
   6. Modal – close success popup
============================================================ */


/* ============================================================
   1. NAVIGATION – HAMBURGER MENU TOGGLE
   On small (mobile) screens, the nav links are hidden.
   When the user taps ☰, we add/remove the class 'open'
   which shows/hides the nav links (via CSS).
============================================================ */
function toggleMenu() {
  // Find the element with class "nav-links"
  var navLinks = document.querySelector('.nav-links');

  // Toggle means: add the class if it's missing, remove if it's there
  navLinks.classList.toggle('open');
}


/* ============================================================
   2. IMAGE SLIDER
   How it works:
   - We have multiple <div class="slide"> elements.
   - Only the one with class "active" is visible (CSS: display:block).
   - We track which slide is current using the variable `currentSlide`.
   - changeSlide(+1) goes to next, changeSlide(-1) goes to previous.
   - Auto-play: setInterval calls changeSlide(1) every 3.5 seconds.
============================================================ */

// currentSlide stores the index of the slide that is currently showing.
// Index 0 = first slide, 1 = second slide, etc.
var currentSlide = 0;

// This function moves to the next or previous slide.
// direction: +1 means next, -1 means previous
function changeSlide(direction) {
  // Get all slide elements on the page
  var slides = document.querySelectorAll('.slide');
  var dots   = document.querySelectorAll('.dot');

  // If there are no slides on this page, stop (other pages don't have a slider)
  if (slides.length === 0) return;

  // Remove 'active' class from the current slide and dot
  slides[currentSlide].classList.remove('active');
  if (dots.length > 0) dots[currentSlide].classList.remove('active');

  // Move to next/previous index
  currentSlide = currentSlide + direction;

  // Wrap around:
  // If we go past the last slide, jump back to the first (index 0)
  // If we go before the first slide, jump to the last
  if (currentSlide >= slides.length) currentSlide = 0;
  if (currentSlide < 0)             currentSlide = slides.length - 1;

  // Add 'active' class to the new current slide and dot
  slides[currentSlide].classList.add('active');
  if (dots.length > 0) dots[currentSlide].classList.add('active');
}

// Jump to a specific slide by clicking a dot
function goToSlide(index) {
  var slides = document.querySelectorAll('.slide');
  var dots   = document.querySelectorAll('.dot');

  if (slides.length === 0) return;

  // Remove active from the old slide
  slides[currentSlide].classList.remove('active');
  if (dots.length > 0) dots[currentSlide].classList.remove('active');

  // Set to chosen index
  currentSlide = index;

  // Add active to new slide
  slides[currentSlide].classList.add('active');
  if (dots.length > 0) dots[currentSlide].classList.add('active');
}

// Auto-play: automatically change slide every 3500 milliseconds (3.5 seconds)
// setInterval(function, delay) runs the function repeatedly at the given delay
setInterval(function() {
  changeSlide(1);
}, 3500);


/* ============================================================
   3. BOOKING PAGE – SET MINIMUM DATE
   We don't want users to select a date in the past.
   So we set the "min" attribute of the date inputs to today.
============================================================ */

// This code runs when the page is fully loaded
window.addEventListener('load', function() {

  // Get references to the date inputs (they may not exist on all pages)
  var checkinInput  = document.getElementById('checkin');
  var checkoutInput = document.getElementById('checkout');

  // Only set min dates if these fields exist (i.e., we're on booking.html)
  if (checkinInput && checkoutInput) {
    // Get today's date as a string in "YYYY-MM-DD" format
    // JavaScript Date object gives us the current date
    var today = new Date();

    // toISOString() returns "YYYY-MM-DDTHH:mm:ss.sssZ"
    // We split at 'T' and take the first part to get just "YYYY-MM-DD"
    var todayString = today.toISOString().split('T')[0];

    // Set minimum selectable date to today (can't pick past dates)
    checkinInput.min  = todayString;
    checkoutInput.min = todayString;
  }
});


/* ============================================================
   4. PRICE CALCULATOR
   This is the core logic. It runs every time the user changes
   room type, check-in date, or check-out date.

   PRICE RULES:
   - Standard Room  = ₹3,000/night
   - Deluxe Room    = ₹5,000/night
   - Suite Room     = ₹8,000/night
   - Dec & Jan      = +20% seasonal surcharge
   - Pet fee        = ₹500 (fixed, one-time)
   - Last-minute    = -10% if check-in is within 7 days from today
============================================================ */
function calculatePrice() {

  // ---------- Step 1: Read values from the form ----------

  var roomType  = document.getElementById('roomType').value;    // "standard", "deluxe", or "suite"
  var checkin   = document.getElementById('checkin').value;      // "YYYY-MM-DD" string
  var checkout  = document.getElementById('checkout').value;     // "YYYY-MM-DD" string

  // Check which radio button is selected for pet
  var petSelected = document.querySelector('input[name="pet"]:checked');
  var petValue    = petSelected ? petSelected.value : 'no';      // "yes" or "no"

  // ---------- Step 2: Stop if fields are incomplete ----------

  // We need all three: room type, check-in, and check-out
  if (!roomType || !checkin || !checkout) {
    document.getElementById('priceDefault').style.display    = 'block';
    document.getElementById('priceBreakdown').style.display  = 'none';
    return; // Exit the function early
  }

  // ---------- Step 3: Calculate number of nights ----------

  // Convert the date strings into Date objects so we can do math
  var checkinDate  = new Date(checkin);
  var checkoutDate = new Date(checkout);

  // Difference in milliseconds, then convert to days
  // 1 day = 24 hours × 60 min × 60 sec × 1000 ms = 86,400,000 ms
  var msPerDay   = 24 * 60 * 60 * 1000;
  var totalNights = Math.round((checkoutDate - checkinDate) / msPerDay);

  // If checkout is not after check-in, stop
  if (totalNights <= 0) {
    document.getElementById('priceDefault').style.display   = 'block';
    document.getElementById('priceBreakdown').style.display = 'none';
    return;
  }

  // ---------- Step 4: Base price per night ----------

  // Use an object to map room type name → price
  // (Like a dictionary: key = room type, value = price)
  var roomPrices = {
    'standard': 3000,
    'deluxe':   5000,
    'suite':    8000
  };

  var pricePerNight = roomPrices[roomType]; // Get price for chosen room
  var basePrice     = pricePerNight * totalNights; // Total before extras

  // ---------- Step 5: Seasonal surcharge (Dec & Jan = +20%) ----------

  // Get the month of the check-in date
  // getMonth() returns 0 for January, 11 for December
  var checkinMonth = checkinDate.getMonth(); // 0 = Jan, 11 = Dec

  var isHighSeason = (checkinMonth === 11 || checkinMonth === 0); // Dec or Jan

  var seasonalAmount = 0;

  if (isHighSeason) {
    // 20% of the base price
    seasonalAmount = Math.round(basePrice * 0.20);
  }

  // ---------- Step 6: Pet fee ----------

  var petFee = (petValue === 'yes') ? 500 : 0;

  // ---------- Step 7: Last-minute discount (within 7 days = -10%) ----------

  // Get today's date (without time, just the date part)
  var today     = new Date();
  today.setHours(0, 0, 0, 0);   // Set time to midnight so only dates are compared
  checkinDate.setHours(0, 0, 0, 0);

  // How many days until check-in?
  var daysUntilCheckin = Math.round((checkinDate - today) / msPerDay);

  // It's a last-minute deal if check-in is 0–7 days from now
  var isLastMinute = (daysUntilCheckin >= 0 && daysUntilCheckin <= 7);

  var discountAmount = 0;

  if (isLastMinute) {
    // 10% discount on base price only (not on pet fee or seasonal surcharge)
    discountAmount = Math.round(basePrice * 0.10);
  }

  // ---------- Step 8: Calculate final total ----------

  // Formula: Base + Seasonal - Discount + Pet Fee
  var finalTotal = basePrice + seasonalAmount - discountAmount + petFee;

  // ---------- Step 9: Update the price panel on screen ----------

  // Helper: format a number as Indian Rupees, e.g. 3000 → "₹3,000"
  function formatRupees(amount) {
    return '₹' + amount.toLocaleString('en-IN');
  }

  // Room type display name (capitalise first letter)
  var roomNames = {
    'standard': 'Standard Room',
    'deluxe':   'Deluxe Room',
    'suite':    'Suite Room'
  };

  // Push values into the HTML elements by their id
  document.getElementById('summaryRoom').textContent   = roomNames[roomType];
  document.getElementById('summaryNights').textContent = totalNights + (totalNights === 1 ? ' Night' : ' Nights');
  document.getElementById('summaryBase').textContent   = formatRupees(basePrice);
  document.getElementById('summaryTotal').textContent  = formatRupees(finalTotal);

  // Show/hide seasonal row depending on whether it applies
  if (isHighSeason) {
    document.getElementById('rowSeasonal').style.display       = 'flex';
    document.getElementById('summarySeasonal').textContent     = '+' + formatRupees(seasonalAmount);
  } else {
    document.getElementById('rowSeasonal').style.display = 'none';
  }

  // Show/hide pet fee row
  if (petValue === 'yes') {
    document.getElementById('rowPet').style.display = 'flex';
  } else {
    document.getElementById('rowPet').style.display = 'none';
  }

  // Show/hide discount row and badge
  if (isLastMinute) {
    document.getElementById('rowDiscount').style.display       = 'flex';
    document.getElementById('summaryDiscount').textContent     = '-' + formatRupees(discountAmount);
    document.getElementById('lastMinuteBadge').style.display   = 'block';
  } else {
    document.getElementById('rowDiscount').style.display     = 'none';
    document.getElementById('lastMinuteBadge').style.display = 'none';
  }

  // Show the full breakdown, hide the placeholder
  document.getElementById('priceDefault').style.display    = 'none';
  document.getElementById('priceBreakdown').style.display  = 'block';
}


/* ============================================================
   5. BOOKING CONFIRMATION
   Validates the form, then shows the success modal if all good.
============================================================ */
function confirmBooking() {

  // Read all form field values
  var name     = document.getElementById('guestName').value.trim();
  var email    = document.getElementById('email').value.trim();
  var phone    = document.getElementById('phone').value.trim();
  var roomType = document.getElementById('roomType').value;
  var checkin  = document.getElementById('checkin').value;
  var checkout = document.getElementById('checkout').value;

  var errorBox = document.getElementById('errorMsg');

  // ---------- Validation ----------

  // Check: name must not be empty
  if (!name) {
    showError('Please enter your name.');
    return;
  }

  // Check: email must contain "@" and "."
  if (!email || !email.includes('@') || !email.includes('.')) {
    showError('Please enter a valid email address.');
    return;
  }

  // Check: phone must be exactly 10 digits
  // We strip spaces and dashes first, then check length
  var cleanPhone = phone.replace(/[\s\-]/g, '');
  if (!cleanPhone || cleanPhone.length < 10) {
    showError('Please enter a valid phone number (at least 10 digits).');
    return;
  }

  // Check: a room must be selected
  if (!roomType) {
    showError('Please select a room type.');
    return;
  }

  // Check: both dates must be selected
  if (!checkin || !checkout) {
    showError('Please select both check-in and check-out dates.');
    return;
  }

  // Check: checkout must be after checkin
  var checkinDate  = new Date(checkin);
  var checkoutDate = new Date(checkout);

  if (checkoutDate <= checkinDate) {
    showError('Check-out date must be after check-in date.');
    return;
  }

  // ---------- All validations passed! ----------

  // Hide any previous error message
  errorBox.style.display = 'none';

  // Build a friendly confirmation message
  var roomNames = {
    'standard': 'Standard Room',
    'deluxe':   'Deluxe Room',
    'suite':    'Suite Room'
  };

  // Format dates nicely: e.g. "15 Dec 2025"
  var options = { day: 'numeric', month: 'short', year: 'numeric' };
  var checkinStr  = checkinDate.toLocaleDateString('en-IN', options);
  var checkoutStr = checkoutDate.toLocaleDateString('en-IN', options);

  var message =
    'Thank you, ' + name + '! \n\n' +
    'Your ' + roomNames[roomType] + ' is reserved from ' +
    checkinStr + ' to ' + checkoutStr + '. ' +
    'A confirmation will be sent to ' + email + '.';

  // Set the message in the modal
  document.getElementById('modalMessage').textContent = message;

  // Show the modal popup
  document.getElementById('successModal').style.display = 'flex';
}

// Helper function to show an error message
function showError(message) {
  var errorBox = document.getElementById('errorMsg');
  errorBox.textContent     = '⚠️ ' + message;
  errorBox.style.display   = 'block';

  // Scroll the error into view so user sees it
  errorBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
}


/* ============================================================
   6. MODAL – CLOSE CONFIRMATION POPUP
   When user clicks "Back to Home" in the modal, we hide it
   and redirect to index.html.
============================================================ */
function closeModal() {
  document.getElementById('successModal').style.display = 'none';
  // Navigate to home page
  window.location.href = 'index.html';
}
